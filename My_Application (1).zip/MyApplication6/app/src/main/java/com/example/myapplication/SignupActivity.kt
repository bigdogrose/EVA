package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.MyApplicationTheme
import androidx.compose.ui.platform.LocalContext  // Make sure to import LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


@OptIn(ExperimentalMaterial3Api::class)
class SignupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                SignupScreen()
            }
        }
    }
}
@OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SignupScreen() {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordMismatchError by remember { mutableStateOf(false) }
    var showSuccess by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (showSuccess) {
                Text("Signup Successful! Redirecting...", style = MaterialTheme.typography.headlineMedium)
                LaunchedEffect(Unit) {
                    delay(2000)  // Delay for 2 seconds to show the message
                    context.startActivity(Intent(context, LoginActivity::class.java))
                }
            } else {
                SignupForm(email, password, confirmPassword, passwordMismatchError, onEmailChange = { email = it },
                    onPasswordChange = { password = it }, onConfirmPasswordChange = { confirmPassword = it },
                    onPasswordMismatchErrorChange = { passwordMismatchError = it }, onDone = {
                        keyboardController?.hide()
                        if (!passwordMismatchError && password.isNotEmpty() && email.isNotEmpty()) {
                            coroutineScope.launch {
                                showSuccess = true
                            }
                        }
                    })
            }
        }
    }
}
@OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SignupForm(email: String, password: String, confirmPassword: String, passwordMismatchError: Boolean,
               onEmailChange: (String) -> Unit, onPasswordChange: (String) -> Unit,
               onConfirmPasswordChange: (String) -> Unit, onPasswordMismatchErrorChange: (Boolean) -> Unit,
               onDone: () -> Unit) {
    Text("Signup Page", style = MaterialTheme.typography.headlineMedium)
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
        value = email,
        onValueChange = onEmailChange,
        label = { Text("Email") },
        singleLine = true,
        keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next)
    )
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
        value = password,
        onValueChange = onPasswordChange,
        label = { Text("Password") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next)
    )
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
        value = confirmPassword,
        onValueChange = {
            onConfirmPasswordChange(it)
            onPasswordMismatchErrorChange(password != it)
        },
        label = { Text("Confirm Password") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
        isError = passwordMismatchError
    )
    if (passwordMismatchError) {
        Text(
            "Passwords do not match",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
    }
    Spacer(modifier = Modifier.height(16.dp))
    Button(
        onClick = onDone,
        enabled = email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty() && !passwordMismatchError
    ) {
        Text("Signup")
    }


}

@Preview(showBackground = true)
@Composable
fun PreviewSignupScreen() {
    MyApplicationTheme {
        SignupScreen()
    }
}
