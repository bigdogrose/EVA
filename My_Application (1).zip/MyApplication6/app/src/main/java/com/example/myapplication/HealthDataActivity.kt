package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence

class HealthDataActivity : ComponentActivity() {
    private lateinit var mqttClient: MqttAsyncClient
    private val serverUri = "tcp://mqtt.eclipseprojects.io:1883"  // MQTT broker URI
    private val clientId = "AndroidClient-${System.currentTimeMillis()}"
    private val topic = "Eva/test"
    private val publishTopic = "Eva/bulb1"  // Topic to publish the "ON" message

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        connectToBroker()
        setContent {
            MyApplicationTheme {
                HealthDataScreen()
            }
        }
    }

    @Composable
    fun HealthDataScreen() {
        var message by remember { mutableStateOf("Waiting for data...") }

        LaunchedEffect(Unit) {
            mqttClient.setCallback(object : MqttCallback {
                override fun connectionLost(cause: Throwable?) {
                    message = "Connection lost: ${cause?.message ?: "Unknown reason"}"
                }

                override fun messageArrived(topic: String?, msg: MqttMessage?) {
                    msg?.let {
                        message = String(it.payload) // Display only the message content
                        publishMessage("ON")  // Publish "ON" to "Eva/bulb1" whenever a message is received
                    }
                }

                override fun deliveryComplete(token: IMqttDeliveryToken?) {
                }
            })
        }

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = message,
                    style = TextStyle(color = Color.Black, fontSize = 24.sp),
                    modifier = Modifier.padding(16.dp).background(Color.LightGray).padding(16.dp))
            }
        }
    }

    private fun connectToBroker() {
        try {
            mqttClient = MqttAsyncClient(serverUri, clientId, MemoryPersistence())
            val options = MqttConnectOptions().apply {
                isCleanSession = true
                isAutomaticReconnect = true
                connectionTimeout = 10
                keepAliveInterval = 20
            }

            mqttClient.connect(options, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.i("MQTT", "Connected successfully to $serverUri")
                    try {
                        mqttClient.subscribe(topic, 1) // Subscribe after successful connection
                        Log.i("MQTT", "Subscribed to $topic")
                    } catch (e: MqttException) {
                        Log.e("MQTT", "Subscription failed", e)
                    }
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.e("MQTT", "Failed to connect to $serverUri", exception)
                }
            })
        } catch (e: MqttException) {
            Log.e("MQTT", "Error connecting to MQTT broker", e)
        }
    }

    private fun publishMessage(message: String) {
        if (mqttClient.isConnected) {
            try {
                mqttClient.publish(publishTopic, MqttMessage(message.toByteArray())).also {
                    Log.i("MQTT", "Message published to $publishTopic: $message")
                }
            } catch (e: MqttException) {
                Log.e("MQTT", "Error publishing message: ${e.message}", e)
            }
        } else {
            Log.e("MQTT", "Cannot publish message, client is not connected.")
        }
    }
}
