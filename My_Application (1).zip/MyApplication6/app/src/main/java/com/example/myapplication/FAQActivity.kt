package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.MyApplicationTheme


class FAQActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                FAQScreen()
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)  // Opt-in to experimental Material3 APIs
    @Composable
    fun FAQScreen() {
        val faqList = listOf(
            "How to look at the health data?" to "Go to the health data button and then wait for your customized data to appear in real time (15 min intervals)",
            "How to connect smart devices?" to "Smart device functionality for now is hardcoded for the sake of testing and development purposes but for now just enjoy pressing the on and off button and seeing a light turn on and off",
            "What is MQTT?" to "MQTT is a lightweight messaging protocol for small sensors and mobile devices. MQTT is how the app is able to process your data and display it to you aswell as your ability to mess with your lightbulb"
        )

        Scaffold(
            topBar = { TopAppBar(title = { Text("FAQ") }) }
        ) { innerPadding ->
            LazyColumn(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
                items(faqList) { faq ->
                    FAQItem(question = faq.first, answer = faq.second)
                    Divider()
                }
            }
        }
    }

    @Composable
    fun FAQItem(question: String, answer: String) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Text(text = question, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = answer, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
