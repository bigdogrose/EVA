package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence

class SmartDevicesActivity : ComponentActivity() {
    private lateinit var mqttClient: MqttAsyncClient
    private val serverUri = "tcp://mqtt.eclipseprojects.io:1883"  // MQTT broker URI
    private val clientId = "AndroidClient-${System.currentTimeMillis()}"
    private val topic = "Eva/bulb1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        connectToMQTT()
        setContent {
            MyApplicationTheme {
                SmartDevicesScreen()
            }
        }
    }

    private fun connectToMQTT() {
        try {
            mqttClient = MqttAsyncClient(serverUri, clientId, MemoryPersistence())
            val options = MqttConnectOptions().apply {
                isCleanSession = true
                isAutomaticReconnect = true
                connectionTimeout = 10
                keepAliveInterval = 20
            }

            mqttClient.connect(options, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.i("MQTT", "Connected successfully to $serverUri")
                    // Optionally, subscribe to a topic if needed upon connection
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.e("MQTT", "Failed to connect to $serverUri", exception)
                }
            })
        } catch (e: MqttException) {
            Log.e("MQTT", "Error initializing MQTT client: ${e.message}", e)
        }
    }

    private fun publishMessage(message: String) {
        try {
            if (mqttClient.isConnected) {
                mqttClient.publish(topic, MqttMessage(message.toByteArray())).also {
                    Log.i("MQTT", "Message published to $topic: $message")
                }
            } else {
                Log.e("MQTT", "Failed to publish: MQTT client is not connected.")
            }
        } catch (e: MqttException) {
            Log.e("MQTT", "Error publishing MQTT message: ${e.message}", e)
        }
    }

    @Composable
    fun SmartDevicesScreen() {
        var isOn by remember { mutableStateOf(false) }
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Kasa Lightbulb", fontSize = 24.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        isOn = !isOn
                        val status = if (isOn) "ON" else "OFF"
                        publishMessage(status)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isOn) Color.Green else Color.Red
                    )
                ) {
                    Text(if (isOn) "ON" else "OFF")
                }
            }
        }
    }
}
